/**
 * <copyright>
 * </copyright>
 *
 */
package org.eclipse.xtext.example.domainmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.domainmodel.DomainmodelPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends StructuralFeature
{
} // Attribute
