package helper;

public class SubType extends SuperType {
	public String myProperty;

	public SubType(String myProperty) {
		super();
		this.myProperty = myProperty;
	}
	
}
