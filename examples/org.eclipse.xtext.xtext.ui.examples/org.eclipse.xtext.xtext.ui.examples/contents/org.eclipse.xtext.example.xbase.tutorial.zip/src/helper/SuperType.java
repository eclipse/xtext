package helper;

public class SuperType {
	@Override
	public String toString() {
		return getClass().getSimpleName();
	}
}
