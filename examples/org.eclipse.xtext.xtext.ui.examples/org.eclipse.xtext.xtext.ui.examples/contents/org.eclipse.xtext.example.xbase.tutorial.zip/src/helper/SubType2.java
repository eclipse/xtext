package helper;

public class SubType2 extends SuperType {
	public String mySubType2Property;

	public SubType2(String mySubType2Property) {
		super();
		this.mySubType2Property = mySubType2Property;
	}
	
}
