
@SuppressWarnings("all")
public class Xbase04_Casts {
	public static void main(String[] args) {
		
		{
		  final CharSequence s = "foo";
		  ((String) s).length();
		}
	}
}
