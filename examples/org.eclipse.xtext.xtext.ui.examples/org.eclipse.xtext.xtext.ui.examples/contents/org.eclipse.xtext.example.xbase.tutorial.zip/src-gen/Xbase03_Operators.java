import helper.OperatorOverloaded;

@SuppressWarnings("all")
public class Xbase03_Operators {
	public static void main(String[] args) {
		
		{
		  final OperatorOverloaded x = new OperatorOverloaded();
		  x.operator_plus("y");
		  x.operator_upTo("y");
		}
	}
}
