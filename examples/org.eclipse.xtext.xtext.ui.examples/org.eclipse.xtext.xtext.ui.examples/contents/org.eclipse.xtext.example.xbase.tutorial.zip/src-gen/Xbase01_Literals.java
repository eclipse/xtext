
@SuppressWarnings("all")
public class Xbase01_Literals {
	public static void main(String[] args) {
		
		{/*null*/;/*"Hello World"*/;/*42*/;/*true*/;/*false*/;/*java.lang.String.class*/;
		}
	}
}
