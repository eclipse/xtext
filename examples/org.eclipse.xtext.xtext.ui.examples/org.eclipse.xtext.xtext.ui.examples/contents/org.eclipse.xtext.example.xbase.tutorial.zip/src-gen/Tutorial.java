
@SuppressWarnings("all")
public class Tutorial {
	public static void main(String[] args) {
	}
}
