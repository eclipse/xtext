package xtext.tutorial.util;

public interface Shape {
}
