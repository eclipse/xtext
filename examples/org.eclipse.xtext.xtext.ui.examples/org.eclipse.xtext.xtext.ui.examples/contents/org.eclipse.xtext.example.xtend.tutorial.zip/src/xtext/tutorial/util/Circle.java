package xtext.tutorial.util;

public class Circle implements Shape {
	public int diameter;

	public Circle(int diameter) {
		super();
		this.diameter = diameter;
	}
	
}
