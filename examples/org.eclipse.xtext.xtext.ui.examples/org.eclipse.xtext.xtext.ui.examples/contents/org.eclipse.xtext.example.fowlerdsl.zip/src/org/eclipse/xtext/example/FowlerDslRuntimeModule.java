/*
Generated with Xtext
*/
package org.eclipse.xtext.example;

import com.google.inject.Binder;

/**
 * used to register components to be used within the IDE.
 */
public class FowlerDslRuntimeModule extends AbstractFowlerDslRuntimeModule {

	@Override
	public void configure(Binder binder) {
		super.configure(binder);
	}
	
}
