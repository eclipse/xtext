/**
 * <copyright>
 * </copyright>
 *
 */
package org.eclipse.xtext.example.gmf.entities;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.gmf.entities.EntitiesPackage#getSimpleType()
 * @model
 * @generated
 */
public interface SimpleType extends Type
{
} // SimpleType
