@SuppressWarnings("all")
public class Tutorial {
  public static void main(final String[] args) {
    try {
    } catch (Throwable t) {}
  }
}
