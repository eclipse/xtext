/**
 * <copyright>
 * </copyright>
 *
 */
package org.eclipse.xtext.example.tutorial.tutorial;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.tutorial.tutorial.TutorialPackage#getDataType()
 * @model
 * @generated
 */
public interface DataType extends Type
{
} // DataType
