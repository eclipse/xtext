package org.eclipse.xtext.example.gmf.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;
import org.eclipse.xtext.example.gmf.diagram.part.EntitiesDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(EntitiesDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
