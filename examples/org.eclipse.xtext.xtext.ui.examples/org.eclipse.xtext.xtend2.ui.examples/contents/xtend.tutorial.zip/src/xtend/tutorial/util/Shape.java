package xtend.tutorial.util;

public interface Shape {
}
