package euler;

import com.google.common.collect.AbstractIterator;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

/**
 * The prime factors of 13195 are 5, 7, 13 and 29.
 * What is the largest prime factor of the number 600851475143 ?
 * 
 * @see http://projecteuler.net/problem=3
 */
@SuppressWarnings("all")
public class Solution_003 extends AbstractIterator<Long> {
  public static void main(final String[] args) {
    Solution_003 _solution_003 = new Solution_003();
    Long _last = IteratorExtensions.<Long>last(_solution_003);
    InputOutput.<Long>println(_last);
  }
  
  private long compound = 600851475143L;
  
  private long sqrt = new Function0<Long>() {
    public Long apply() {
      double _sqrt = Math.sqrt(Solution_003.this.compound);
      long _longValue = Double.valueOf(_sqrt).longValue();
      return _longValue;
    }
  }.apply();
  
  private long current = 2;
  
  protected Long computeNext() {
    Long _xblockexpression = null;
    {
      boolean _lessThan = (this.current < this.sqrt);
      boolean _while = _lessThan;
      while (_while) {
        {
          boolean _and = false;
          long _modulo = (this.compound % this.current);
          boolean _equals = (_modulo == 0);
          if (!_equals) {
            _and = false;
          } else {
            boolean _isPrime = this.isPrime(this.current);
            _and = (_equals && _isPrime);
          }
          if (_and) {
            long result = this.current;
            long _plus = (this.current + 1);
            this.current = _plus;
            return Long.valueOf(result);
          }
          long _plus_1 = (this.current + 1);
          this.current = _plus_1;
        }
        boolean _lessThan_1 = (this.current < this.sqrt);
        _while = _lessThan_1;
      }
      Long _endOfData = this.endOfData();
      _xblockexpression = (_endOfData);
    }
    return _xblockexpression;
  }
  
  public boolean isPrime(final long l) {
    double _sqrt = Math.sqrt(l);
    int _intValue = Double.valueOf(_sqrt).intValue();
    IntegerRange _upTo = new IntegerRange(2, _intValue);
    final Function1<Integer,Boolean> _function = new Function1<Integer,Boolean>() {
        public Boolean apply(final Integer i) {
          long _modulo = (l % i);
          boolean _equals = (_modulo == 0);
          return Boolean.valueOf(_equals);
        }
      };
    Iterable<Integer> _filter = IterableExtensions.<Integer>filter(_upTo, _function);
    boolean _isEmpty = IterableExtensions.isEmpty(_filter);
    return _isEmpty;
  }
}
