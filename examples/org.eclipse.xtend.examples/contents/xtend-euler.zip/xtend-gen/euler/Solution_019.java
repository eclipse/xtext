package euler;

import java.util.Calendar;
import java.util.GregorianCalendar;
import org.eclipse.xtext.xbase.lib.InputOutput;

/**
 * You are given the following information, but you may prefer to do some research for yourself.
 * 
 *  1 Jan 1900 was a Monday.
 *  Thirty days has September,
 *  April, June and November.
 *  All the rest have thirty-one,
 *  Saving February alone,
 *  Which has twenty-eight, rain or shine.
 *  And on leap years, twenty-nine.
 *  A leap year occurs on any year evenly divisible by 4, but not on a century unless it is divisible by 400.
 * 
 * How many Sundays fell on the first of the month during the twentieth century (1 Jan 1901 to 31 Dec 2000)?
 * 
 * @see http://projecteuler.net/problem=19
 */
@SuppressWarnings("all")
public class Solution_019 {
  public static void main(final String[] args) {
    final Calendar calendar = GregorianCalendar.getInstance();
    calendar.set(1901, 1, 1);
    int result = 0;
    boolean _dowhile = false;
    do {
      {
        int _get = calendar.get(Calendar.DAY_OF_WEEK);
        boolean _equals = (_get == Calendar.SUNDAY);
        if (_equals) {
          int _plus = (result + 1);
          result = _plus;
        }
        calendar.add(Calendar.MONTH, 1);
      }
      int _get = calendar.get(Calendar.YEAR);
      boolean _lessEqualsThan = (_get <= 2000);
      _dowhile = _lessEqualsThan;
    } while(_dowhile);
    InputOutput.<Integer>println(Integer.valueOf(result));
  }
}
