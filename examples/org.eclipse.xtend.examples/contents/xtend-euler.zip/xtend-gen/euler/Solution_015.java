package euler;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

/**
 * Starting in the top left corner of a 2�2 grid, there are 6 routes (without backtracking) to the bottom right corner.
 * How many routes are there through a 20�20 grid?
 * 
 * @see http://projecteuler.net/problem=15
 */
@SuppressWarnings("all")
public class Solution_015 {
  public static void main(final String[] args) {
    Solution_015 _solution_015 = new Solution_015(20);
    Long _solve = _solution_015.solve();
    InputOutput.<Long>println(_solve);
  }
  
  private List<Long> solutions;
  
  private int internalGridSize;
  
  private int numberOfNodes;
  
  public Solution_015(final int gridSize) {
    int _plus = (gridSize + 1);
    this.internalGridSize = _plus;
    int _multiply = (this.internalGridSize * this.internalGridSize);
    this.numberOfNodes = _multiply;
    ArrayList<Long> _newArrayList = CollectionLiterals.<Long>newArrayList();
    this.solutions = _newArrayList;
    int _minus = (this.numberOfNodes - 2);
    IntegerRange _upTo = new IntegerRange(0, _minus);
    final Procedure1<Integer> _function = new Procedure1<Integer>() {
        public void apply(final Integer it) {
          long _minus = (-1L);
          Solution_015.this.solutions.add(Long.valueOf(_minus));
        }
      };
    IterableExtensions.<Integer>forEach(_upTo, _function);
    this.solutions.add(Long.valueOf(1L));
  }
  
  public Long solve() {
    Long _solve = this.solve(0);
    return _solve;
  }
  
  public Long solve(final int position) {
    boolean _isValid = this.isValid(position);
    if (_isValid) {
      Long _xifexpression = null;
      boolean _done = this.done(position);
      if (_done) {
        Long _get = this.solutions.get(position);
        _xifexpression = _get;
      } else {
        long _xblockexpression = (long) 0;
        {
          int _moveRight = this.moveRight(position);
          Long _solve = this.solve(_moveRight);
          int _moveDown = this.moveDown(position);
          Long _solve_1 = this.solve(_moveDown);
          long result = ((_solve).longValue() + (_solve_1).longValue());
          this.solutions.set(position, Long.valueOf(result));
          _xblockexpression = (result);
        }
        _xifexpression = _xblockexpression;
      }
      return _xifexpression;
    }
    return Long.valueOf(0L);
  }
  
  public int moveDown(final int atIndex) {
    int _plus = (atIndex + this.internalGridSize);
    return _plus;
  }
  
  public int moveRight(final int atIndex) {
    int _xblockexpression = (int) 0;
    {
      int _plus = (atIndex + 1);
      int _modulo = (_plus % this.internalGridSize);
      boolean _equals = (_modulo == 0);
      if (_equals) {
        return (-1);
      }
      int _plus_1 = (atIndex + 1);
      _xblockexpression = (_plus_1);
    }
    return Integer.valueOf(_xblockexpression);
  }
  
  public boolean isValid(final int index) {
    boolean _and = false;
    boolean _greaterEqualsThan = (index >= 0);
    if (!_greaterEqualsThan) {
      _and = false;
    } else {
      boolean _lessThan = (index < this.numberOfNodes);
      _and = (_greaterEqualsThan && _lessThan);
    }
    return _and;
  }
  
  public boolean done(final int index) {
    Long _get = this.solutions.get(index);
    int _minus = (-1);
    boolean _notEquals = ((_get).longValue() != _minus);
    return _notEquals;
  }
}
