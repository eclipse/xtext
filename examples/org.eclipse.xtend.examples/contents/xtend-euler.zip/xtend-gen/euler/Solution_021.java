package euler;

import com.google.common.base.Objects;
import java.util.HashSet;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Let d(n) be defined as the sum of proper divisors of n (numbers less than n which divide evenly into n).
 * If d(a) = b and d(b) = a, where a != b, then a and b are an amicable pair and each of a and b are called amicable numbers.
 * 
 * For example, the proper divisors of 220 are 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 and 110; therefore d(220) = 284.
 * The proper divisors of 284 are 1, 2, 4, 71 and 142; so d(284) = 220.
 * 
 * Evaluate the sum of all the amicable numbers under 10000.
 * 
 * @see http://projecteuler.net/problem=21
 */
@SuppressWarnings("all")
public class Solution_021 {
  public static void main(final String[] args) {
    HashSet<Integer> result = CollectionLiterals.<Integer>newHashSet();
    final int max = 10000;
    IntegerRange _upTo = new IntegerRange(1, max);
    for (final Integer i : _upTo) {
      boolean _contains = result.contains(i);
      boolean _not = (!_contains);
      if (_not) {
        final Integer sumOfDivisors = Solution_021.sumOfDivisors((i).intValue());
        boolean _and = false;
        boolean _notEquals = (!Objects.equal(sumOfDivisors, i));
        if (!_notEquals) {
          _and = false;
        } else {
          boolean _lessEqualsThan = ((sumOfDivisors).intValue() <= max);
          _and = (_notEquals && _lessEqualsThan);
        }
        if (_and) {
          final Integer otherSumOfDivisors = Solution_021.sumOfDivisors((sumOfDivisors).intValue());
          boolean _equals = Objects.equal(otherSumOfDivisors, i);
          if (_equals) {
            result.add(i);
            result.add(sumOfDivisors);
          }
        }
      }
    }
    final Function2<Integer,Integer,Integer> _function = new Function2<Integer,Integer,Integer>() {
        public Integer apply(final Integer i1, final Integer i2) {
          int _plus = ((i1).intValue() + (i2).intValue());
          return Integer.valueOf(_plus);
        }
      };
    Integer _reduce = IterableExtensions.<Integer>reduce(result, _function);
    InputOutput.<Integer>println(_reduce);
  }
  
  public static Integer sumOfDivisors(final int input) {
    Integer _xblockexpression = null;
    {
      double _sqrt = Math.sqrt(input);
      double _floor = Math.floor(_sqrt);
      final int sqrt = Double.valueOf(_floor).intValue();
      IntegerRange _upTo = new IntegerRange(2, sqrt);
      final Function1<Integer,Boolean> _function = new Function1<Integer,Boolean>() {
          public Boolean apply(final Integer div) {
            int _modulo = (input % div);
            boolean _equals = (_modulo == 0);
            return Boolean.valueOf(_equals);
          }
        };
      Iterable<Integer> _filter = IterableExtensions.<Integer>filter(_upTo, _function);
      final Function2<Integer,Integer,Integer> _function_1 = new Function2<Integer,Integer,Integer>() {
          public Integer apply(final Integer i1, final Integer i2) {
            int _xblockexpression = (int) 0;
            {
              final int other = (input / (i2).intValue());
              int _xifexpression = (int) 0;
              boolean _notEquals = (other != (i2).intValue());
              if (_notEquals) {
                int _plus = ((i1).intValue() + (i2).intValue());
                int _plus_1 = (_plus + other);
                _xifexpression = _plus_1;
              } else {
                int _plus_2 = ((i1).intValue() + (i2).intValue());
                _xifexpression = _plus_2;
              }
              _xblockexpression = (_xifexpression);
            }
            return Integer.valueOf(_xblockexpression);
          }
        };
      Integer _fold = IterableExtensions.<Integer, Integer>fold(_filter, Integer.valueOf(1), _function_1);
      _xblockexpression = (_fold);
    }
    return _xblockexpression;
  }
}
