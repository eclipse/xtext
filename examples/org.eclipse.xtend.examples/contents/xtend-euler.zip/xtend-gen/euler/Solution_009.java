package euler;

import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

/**
 * A Pythagorean triplet is a set of three natural numbers, a < b < c, for which,
 * a^2 + b^2 = c^2
 * 
 * For example, 3^2 + 4^2 = 9 + 16 = 25 = 5^2.
 * There exists exactly one Pythagorean triplet for which a + b + c = 1000.
 * Find the product abc.
 * 
 * @see http://projecteuler.net/problem=9
 */
@SuppressWarnings("all")
public class Solution_009 {
  public static void main(final String[] args) {
    IntegerRange _upTo = new IntegerRange(1, 1000);
    final Procedure1<Integer> _function = new Procedure1<Integer>() {
        public void apply(final Integer a) {
          int _plus = ((a).intValue() + 1);
          int _minus = (1000 - (a).intValue());
          IntegerRange _upTo = new IntegerRange(_plus, _minus);
          final Procedure1<Integer> _function = new Procedure1<Integer>() {
              public void apply(final Integer b) {
                int _minus = (1000 - (a).intValue());
                int c = (_minus - (b).intValue());
                boolean _greaterEqualsThan = (c >= 0);
                if (_greaterEqualsThan) {
                  int _multiply = ((a).intValue() * (a).intValue());
                  int _multiply_1 = ((b).intValue() * (b).intValue());
                  int _plus = (_multiply + _multiply_1);
                  int _multiply_2 = (c * c);
                  boolean _equals = (_plus == _multiply_2);
                  if (_equals) {
                    StringConcatenation _builder = new StringConcatenation();
                    _builder.append("a = ");
                    _builder.append(a, "");
                    _builder.newLineIfNotEmpty();
                    _builder.append("b = ");
                    _builder.append(b, "");
                    _builder.newLineIfNotEmpty();
                    _builder.append("c = ");
                    _builder.append(c, "");
                    _builder.newLineIfNotEmpty();
                    _builder.append("product = ");
                    int _multiply_3 = ((a).intValue() * (b).intValue());
                    int _multiply_4 = (_multiply_3 * c);
                    _builder.append(_multiply_4, "");
                    _builder.newLineIfNotEmpty();
                    InputOutput.<CharSequence>println(_builder);
                  }
                }
              }
            };
          IterableExtensions.<Integer>forEach(_upTo, _function);
        }
      };
    IterableExtensions.<Integer>forEach(_upTo, _function);
  }
}
