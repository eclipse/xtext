package euler;

import com.google.common.base.Objects;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * If the numbers 1 to 5 are written out in words: one, two, three, four, five, then there are 3 + 3 + 5 + 4 + 4 = 19 letters used in total.
 * 
 * If all the numbers from 1 to 1000 (one thousand) inclusive were written out in words, how many letters would be used?
 * 
 * NOTE: Do not count spaces or hyphens. For example, 342 (three hundred and forty-two) contains 23 letters and 115 (one hundred and fifteen) contains 20 letters.
 * The use of "and" when writing out numbers is in compliance with British usage.
 * 
 * @see http://projecteuler.net/problem=17
 */
@SuppressWarnings("all")
public class Solution_017 {
  public static void main(final String[] args) {
    Solution_017 _solution_017 = new Solution_017(1000);
    Iterable<Integer> _solve = _solution_017.solve();
    InputOutput.<Iterable<Integer>>println(_solve);
  }
  
  private int upper;
  
  public Solution_017(final int upper) {
    this.upper = upper;
  }
  
  public Iterable<Integer> solve() {
    IntegerRange _upTo = new IntegerRange(1, this.upper);
    final Function1<Integer,Integer> _function = new Function1<Integer,Integer>() {
        public Integer apply(final Integer it) {
          String _word = Solution_017.this.word((it).intValue());
          String _replace = _word.replace(" ", "");
          int _length = _replace.length();
          return Integer.valueOf(_length);
        }
      };
    Iterable<Integer> _map = IterableExtensions.<Integer, Integer>map(_upTo, _function);
    return _map;
  }
  
  public String word(final int number) {
    String _xifexpression = null;
    boolean _greaterEqualsThan = (number >= 1000);
    if (_greaterEqualsThan) {
      int _divide = (number / 1000);
      String _word = this.word(_divide);
      String _plus = (_word + " thousand ");
      int _modulo = (number % 1000);
      String _word_1 = this.word(_modulo);
      String _plus_1 = (_plus + _word_1);
      _xifexpression = _plus_1;
    } else {
      String _xifexpression_1 = null;
      boolean _greaterEqualsThan_1 = (number >= 100);
      if (_greaterEqualsThan_1) {
        String _xblockexpression = null;
        {
          int remainder = (number % 100);
          int _divide_1 = (number / 100);
          String _word_2 = this.word(_divide_1);
          String _plus_2 = (_word_2 + " hundred");
          String _xifexpression_2 = null;
          boolean _notEquals = (remainder != 0);
          if (_notEquals) {
            String _word_3 = this.word(remainder);
            String _plus_3 = (" and " + _word_3);
            _xifexpression_2 = _plus_3;
          } else {
            _xifexpression_2 = "";
          }
          String _plus_4 = (_plus_2 + _xifexpression_2);
          _xblockexpression = (_plus_4);
        }
        _xifexpression_1 = _xblockexpression;
      } else {
        String _wordToHundred = this.wordToHundred(number);
        _xifexpression_1 = _wordToHundred;
      }
      _xifexpression = _xifexpression_1;
    }
    return _xifexpression;
  }
  
  public String wordToHundred(final int number) {
    String _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(number,0)) {
        _matched=true;
        _switchResult = "";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,1)) {
        _matched=true;
        _switchResult = "one";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,2)) {
        _matched=true;
        _switchResult = "two";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,3)) {
        _matched=true;
        _switchResult = "three";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,4)) {
        _matched=true;
        _switchResult = "four";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,5)) {
        _matched=true;
        _switchResult = "five";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,6)) {
        _matched=true;
        _switchResult = "six";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,7)) {
        _matched=true;
        _switchResult = "seven";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,8)) {
        _matched=true;
        _switchResult = "eight";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,9)) {
        _matched=true;
        _switchResult = "nine";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,10)) {
        _matched=true;
        _switchResult = "ten";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,11)) {
        _matched=true;
        _switchResult = "eleven";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,12)) {
        _matched=true;
        _switchResult = "twelve";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,13)) {
        _matched=true;
        _switchResult = "thirteen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,14)) {
        _matched=true;
        _switchResult = "fourteen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,15)) {
        _matched=true;
        _switchResult = "fifteen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,16)) {
        _matched=true;
        _switchResult = "sixteen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,17)) {
        _matched=true;
        _switchResult = "seventeen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,18)) {
        _matched=true;
        _switchResult = "eighteen";
      }
    }
    if (!_matched) {
      if (Objects.equal(number,19)) {
        _matched=true;
        _switchResult = "nineteen";
      }
    }
    if (!_matched) {
      boolean _lessThan = (number < 30);
      if (_lessThan) {
        _matched=true;
        int _modulo = (number % 10);
        String _wordToHundred = this.wordToHundred(_modulo);
        String _plus = ("twenty " + _wordToHundred);
        _switchResult = _plus;
      }
    }
    if (!_matched) {
      boolean _lessThan_1 = (number < 40);
      if (_lessThan_1) {
        _matched=true;
        int _modulo_1 = (number % 10);
        String _wordToHundred_1 = this.wordToHundred(_modulo_1);
        String _plus_1 = ("thirty " + _wordToHundred_1);
        _switchResult = _plus_1;
      }
    }
    if (!_matched) {
      boolean _lessThan_2 = (number < 50);
      if (_lessThan_2) {
        _matched=true;
        int _modulo_2 = (number % 10);
        String _wordToHundred_2 = this.wordToHundred(_modulo_2);
        String _plus_2 = ("forty " + _wordToHundred_2);
        _switchResult = _plus_2;
      }
    }
    if (!_matched) {
      boolean _lessThan_3 = (number < 60);
      if (_lessThan_3) {
        _matched=true;
        int _modulo_3 = (number % 10);
        String _wordToHundred_3 = this.wordToHundred(_modulo_3);
        String _plus_3 = ("fifty " + _wordToHundred_3);
        _switchResult = _plus_3;
      }
    }
    if (!_matched) {
      boolean _lessThan_4 = (number < 70);
      if (_lessThan_4) {
        _matched=true;
        int _modulo_4 = (number % 10);
        String _wordToHundred_4 = this.wordToHundred(_modulo_4);
        String _plus_4 = ("sixty " + _wordToHundred_4);
        _switchResult = _plus_4;
      }
    }
    if (!_matched) {
      boolean _lessThan_5 = (number < 80);
      if (_lessThan_5) {
        _matched=true;
        int _modulo_5 = (number % 10);
        String _wordToHundred_5 = this.wordToHundred(_modulo_5);
        String _plus_5 = ("seventy " + _wordToHundred_5);
        _switchResult = _plus_5;
      }
    }
    if (!_matched) {
      boolean _lessThan_6 = (number < 90);
      if (_lessThan_6) {
        _matched=true;
        int _modulo_6 = (number % 10);
        String _wordToHundred_6 = this.wordToHundred(_modulo_6);
        String _plus_6 = ("eighty " + _wordToHundred_6);
        _switchResult = _plus_6;
      }
    }
    if (!_matched) {
      boolean _lessThan_7 = (number < 100);
      if (_lessThan_7) {
        _matched=true;
        int _modulo_7 = (number % 10);
        String _wordToHundred_7 = this.wordToHundred(_modulo_7);
        String _plus_7 = ("ninety " + _wordToHundred_7);
        _switchResult = _plus_7;
      }
    }
    return _switchResult;
  }
}
