package euler;

import java.math.BigInteger;
import java.util.List;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

/**
 * 2^15 = 32768 and the sum of its digits is 3 + 2 + 7 + 6 + 8 = 26.
 * 
 * What is the sum of the digits of the number 2^1000?
 * 
 * @see http://projecteuler.net/problem=16
 */
@SuppressWarnings("all")
public class Solution_016 {
  public static void main(final String[] args) {
    BigInteger _pow = BigInteger.valueOf(2L).pow(1000);
    String _string = _pow.toString();
    char[] _charArray = _string.toCharArray();
    final Function1<Character,Integer> _function = new Function1<Character,Integer>() {
        public Integer apply(final Character it) {
          char _charValue = it.charValue();
          int _numericValue = Character.getNumericValue(_charValue);
          return Integer.valueOf(_numericValue);
        }
      };
    List<Integer> _map = ListExtensions.<Character, Integer>map(((List<Character>)Conversions.doWrapArray(_charArray)), _function);
    final Function2<Integer,Integer,Integer> _function_1 = new Function2<Integer,Integer,Integer>() {
        public Integer apply(final Integer i1, final Integer i2) {
          int _plus = (i1 + i2);
          return Integer.valueOf(_plus);
        }
      };
    Integer _reduce = IterableExtensions.<Integer>reduce(_map, _function_1);
    InputOutput.<Integer>println(_reduce);
  }
}
