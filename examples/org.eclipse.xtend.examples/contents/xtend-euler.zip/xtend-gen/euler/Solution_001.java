package euler;

import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * If we list all the natural numbers below 10 that are multiples of 3 or 5, we get 3, 5, 6 and 9.
 * The sum of these multiples is 23.
 * 
 * Find the sum of all the multiples of 3 or 5 below 1000.
 * 
 * @see http://projecteuler.net/problem=1
 */
@SuppressWarnings("all")
public class Solution_001 {
  public static void main(final String[] args) {
    IntegerRange _upTo = new IntegerRange(1, 999);
    final Function1<Integer,Boolean> _function = new Function1<Integer,Boolean>() {
        public Boolean apply(final Integer i) {
          boolean _or = false;
          int _modulo = ((i).intValue() % 3);
          boolean _equals = (_modulo == 0);
          if (_equals) {
            _or = true;
          } else {
            int _modulo_1 = ((i).intValue() % 5);
            boolean _equals_1 = (_modulo_1 == 0);
            _or = (_equals || _equals_1);
          }
          return Boolean.valueOf(_or);
        }
      };
    Iterable<Integer> _filter = IterableExtensions.<Integer>filter(_upTo, _function);
    final Function2<Integer,Integer,Integer> _function_1 = new Function2<Integer,Integer,Integer>() {
        public Integer apply(final Integer i1, final Integer i2) {
          int _plus = ((i1).intValue() + (i2).intValue());
          return Integer.valueOf(_plus);
        }
      };
    Integer _reduce = IterableExtensions.<Integer>reduce(_filter, _function_1);
    InputOutput.<Integer>println(_reduce);
  }
}
