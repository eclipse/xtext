package euler;

import java.util.Set;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * A perfect number is a number for which the sum of its proper divisors is exactly equal to the number.
 * For example, the sum of the proper divisors of 28 would be 1 + 2 + 4 + 7 + 14 = 28, which means that 28 is a perfect number.
 * A number n is called deficient if the sum of its proper divisors is less than n and it is called abundant if this sum exceeds n.
 * 
 * As 12 is the smallest abundant number, 1 + 2 + 3 + 4 + 6 = 16, the smallest number that can be written as the sum of two abundant numbers is 24.
 * By mathematical analysis, it can be shown that all integers greater than 28123 can be written as the sum of two abundant numbers.
 * However, this upper limit cannot be reduced any further by analysis even though it is known that the greatest number that cannot
 * be expressed as the sum of two abundant numbers is less than this limit.
 * 
 * Find the sum of all the positive integers which cannot be written as the sum of two abundant numbers.
 * 
 * @see http://projecteuler.net/problem=23
 */
@SuppressWarnings("all")
public class Solution_023 {
  public static void main(final String[] args) {
    IntegerRange _upTo = new IntegerRange(28123, 1);
    final Function1<Integer,Boolean> _function = new Function1<Integer,Boolean>() {
        public Boolean apply(final Integer it) {
          boolean _isAbundant = Solution_023.isAbundant((it).intValue());
          return Boolean.valueOf(_isAbundant);
        }
      };
    Iterable<Integer> _filter = IterableExtensions.<Integer>filter(_upTo, _function);
    final Set<Integer> allAbundantNumbers = IterableExtensions.<Integer>toSet(_filter);
    IntegerRange _upTo_1 = new IntegerRange(28123, 1);
    final Function1<Integer,Boolean> _function_1 = new Function1<Integer,Boolean>() {
        public Boolean apply(final Integer it) {
          boolean _isSumOfAbundantNumbers = Solution_023.isSumOfAbundantNumbers((it).intValue(), allAbundantNumbers);
          boolean _not = (!_isSumOfAbundantNumbers);
          return Boolean.valueOf(_not);
        }
      };
    Iterable<Integer> _filter_1 = IterableExtensions.<Integer>filter(_upTo_1, _function_1);
    final Function2<Integer,Integer,Integer> _function_2 = new Function2<Integer,Integer,Integer>() {
        public Integer apply(final Integer i1, final Integer i2) {
          int _plus = ((i1).intValue() + (i2).intValue());
          return Integer.valueOf(_plus);
        }
      };
    Integer _reduce = IterableExtensions.<Integer>reduce(_filter_1, _function_2);
    InputOutput.<Integer>println(_reduce);
  }
  
  public static boolean isSumOfAbundantNumbers(final int input, final Set<Integer> allAmbundantNumbers) {
    for (final Integer i : allAmbundantNumbers) {
      int _minus = (input - (i).intValue());
      boolean _contains = allAmbundantNumbers.contains(Integer.valueOf(_minus));
      if (_contains) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean isAbundant(final int input) {
    double _sqrt = Math.sqrt(input);
    double _floor = Math.floor(_sqrt);
    final int sqrt = Double.valueOf(_floor).intValue();
    IntegerRange _upTo = new IntegerRange(2, sqrt);
    final Function1<Integer,Boolean> _function = new Function1<Integer,Boolean>() {
        public Boolean apply(final Integer div) {
          boolean _and = false;
          boolean _notEquals = (div != input);
          if (!_notEquals) {
            _and = false;
          } else {
            int _modulo = (input % div);
            boolean _equals = (_modulo == 0);
            _and = (_notEquals && _equals);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<Integer> _filter = IterableExtensions.<Integer>filter(_upTo, _function);
    final Function2<Integer,Integer,Integer> _function_1 = new Function2<Integer,Integer,Integer>() {
        public Integer apply(final Integer i1, final Integer i2) {
          int _xblockexpression = (int) 0;
          {
            final int other = (input / (i2).intValue());
            int _xifexpression = (int) 0;
            boolean _and = false;
            boolean _notEquals = (other != (i2).intValue());
            if (!_notEquals) {
              _and = false;
            } else {
              boolean _notEquals_1 = (other != input);
              _and = (_notEquals && _notEquals_1);
            }
            if (_and) {
              int _plus = ((i1).intValue() + (i2).intValue());
              int _plus_1 = (_plus + other);
              _xifexpression = _plus_1;
            } else {
              int _plus_2 = ((i1).intValue() + (i2).intValue());
              _xifexpression = _plus_2;
            }
            _xblockexpression = (_xifexpression);
          }
          return Integer.valueOf(_xblockexpression);
        }
      };
    final Integer sumOfDivisors = IterableExtensions.<Integer, Integer>fold(_filter, Integer.valueOf(1), _function_1);
    return ((sumOfDivisors).intValue() > input);
  }
}
