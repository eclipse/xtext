/**
 * Copyright (c) 2012 itemis AG (http://www.itemis.eu) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Author - Sebastian Zarnekow
 * See https://github.com/szarnekow/xtend-euler
 */
package euler;

import java.util.ArrayList;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

/**
 * Starting in the top left corner of a 2�2 grid, there are 6 routes (without backtracking) to the bottom right corner.
 * How many routes are there through a 20�20 grid?
 * 
 * @see http://projecteuler.net/problem=15
 */
@SuppressWarnings("all")
public class Solution_015b {
  public static void main(final String[] args) {
    final int gridSize = 20;
    final ArrayList<Long> it = CollectionLiterals.<Long>newArrayList();
    int _plus = (gridSize + 1);
    IntegerRange _upTo = new IntegerRange(1, _plus);
    final Procedure1<Integer> _function = new Procedure1<Integer>() {
        public void apply(final Integer col) {
          it.add(Long.valueOf(1L));
        }
      };
    IterableExtensions.<Integer>forEach(_upTo, _function);
    IntegerRange _upTo_1 = new IntegerRange(1, gridSize);
    final Procedure1<Integer> _function_1 = new Procedure1<Integer>() {
        public void apply(final Integer row) {
          IntegerRange _upTo = new IntegerRange(1, gridSize);
          final Procedure1<Integer> _function = new Procedure1<Integer>() {
              public void apply(final Integer col) {
                int _minus = ((col).intValue() - 1);
                Long _get = it.get(_minus);
                Long _get_1 = it.get((col).intValue());
                long _plus = ((_get).longValue() + (_get_1).longValue());
                it.set((col).intValue(), Long.valueOf(_plus));
              }
            };
          IterableExtensions.<Integer>forEach(_upTo, _function);
        }
      };
    IterableExtensions.<Integer>forEach(_upTo_1, _function_1);
    Long _last = IterableExtensions.<Long>last(it);
    InputOutput.<Long>println(_last);
  }
}
