package euler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * By listing the first six prime numbers: 2, 3, 5, 7, 11, and 13, we can see that the 6th prime is 13.
 * What is the 10 001st prime number?
 * 
 * @see http://projecteuler.net/problem=7
 */
@SuppressWarnings("all")
public class Solution_007 {
  public static void main(final String[] args) {
    int n = 10001;
    ArrayList<Integer> seenPrimes = CollectionLiterals.<Integer>newArrayList();
    int slice = 0;
    boolean _while = true;
    while (_while) {
      {
        int _multiply = (slice * n);
        int _plus = (_multiply + 1);
        int _plus_1 = (slice + 1);
        int _multiply_1 = (_plus_1 * n);
        IntegerRange _upTo = new IntegerRange(_plus, _multiply_1);
        List<Integer> numbers = IterableExtensions.<Integer>toList(_upTo);
        for (final Integer prime : seenPrimes) {
          Solution_007.markAsNotPrime((prime).intValue(), numbers);
        }
        int _plus_2 = (slice + 1);
        slice = _plus_2;
        boolean _isEmpty = numbers.isEmpty();
        boolean _not = (!_isEmpty);
        boolean _while_1 = _not;
        while (_while_1) {
          {
            Integer nextPrime = numbers.remove(0);
            boolean _notEquals = ((nextPrime).intValue() != 1);
            if (_notEquals) {
              seenPrimes.add(nextPrime);
              int _size = seenPrimes.size();
              boolean _equals = (_size == n);
              if (_equals) {
                InputOutput.<Integer>println(nextPrime);
                return;
              }
              Solution_007.markAsNotPrime((nextPrime).intValue(), numbers);
            }
          }
          boolean _isEmpty_1 = numbers.isEmpty();
          boolean _not_1 = (!_isEmpty_1);
          _while_1 = _not_1;
        }
      }
      _while = true;
    }
  }
  
  public static void markAsNotPrime(final int prime, final List<Integer> numbers) {
    Iterator<Integer> iter = numbers.iterator();
    boolean _hasNext = iter.hasNext();
    boolean _while = _hasNext;
    while (_while) {
      Integer _next = iter.next();
      int _modulo = ((_next).intValue() % prime);
      boolean _equals = (_modulo == 0);
      if (_equals) {
        iter.remove();
      }
      boolean _hasNext_1 = iter.hasNext();
      _while = _hasNext_1;
    }
  }
}
