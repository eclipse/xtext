/**
 * Copyright (c) 2012 itemis AG (http://www.itemis.eu) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Author - Sebastian Zarnekow
 * See https://github.com/szarnekow/xtend-euler
 */
package euler;

import java.util.ArrayList;
import java.util.Iterator;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * The sum of the primes below 10 is 2 + 3 + 5 + 7 = 17.
 * Find the sum of all the primes below two million.
 * 
 * @see http://projecteuler.net/problem=10
 */
@SuppressWarnings("all")
public class Solution_010 {
  public static void main(final String[] args) {
    ArrayList<Long> primes = CollectionLiterals.<Long>newArrayList();
    IntegerRange _upTo = new IntegerRange(2, 1999999);
    for (final Integer i : _upTo) {
      {
        Iterator<Long> primeIter = primes.iterator();
        boolean isPrime = true;
        long knownPrime = 0L;
        boolean _and = false;
        boolean _and_1 = false;
        if (!isPrime) {
          _and_1 = false;
        } else {
          long _multiply = (knownPrime * knownPrime);
          boolean _lessThan = (_multiply < (i).intValue());
          _and_1 = (isPrime && _lessThan);
        }
        if (!_and_1) {
          _and = false;
        } else {
          boolean _hasNext = primeIter.hasNext();
          _and = (_and_1 && _hasNext);
        }
        boolean _while = _and;
        while (_while) {
          {
            Long _next = primeIter.next();
            knownPrime = (_next).longValue();
            long _modulo = ((i).intValue() % knownPrime);
            boolean _equals = (_modulo == 0);
            if (_equals) {
              isPrime = false;
            }
          }
          boolean _and_2 = false;
          boolean _and_3 = false;
          if (!isPrime) {
            _and_3 = false;
          } else {
            long _multiply_1 = (knownPrime * knownPrime);
            boolean _lessThan_1 = (_multiply_1 < (i).intValue());
            _and_3 = (isPrime && _lessThan_1);
          }
          if (!_and_3) {
            _and_2 = false;
          } else {
            boolean _hasNext_1 = primeIter.hasNext();
            _and_2 = (_and_3 && _hasNext_1);
          }
          _while = _and_2;
        }
        if (isPrime) {
          primes.add(Long.valueOf(((long) (i).intValue())));
        }
      }
    }
    final Function2<Long,Long,Long> _function = new Function2<Long,Long,Long>() {
        public Long apply(final Long i1, final Long i2) {
          long _plus = ((i1).longValue() + (i2).longValue());
          return Long.valueOf(_plus);
        }
      };
    Long _reduce = IterableExtensions.<Long>reduce(primes, _function);
    InputOutput.<Long>println(_reduce);
  }
}
