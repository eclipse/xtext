package observables;

import observables.ObservableCompilationParticipant;
import org.eclipse.xtend.lib.macro.Active;

@Active(ObservableCompilationParticipant.class)
public @interface Observable {
}
