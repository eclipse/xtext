/*
Generated with Xtext
*/
package org.eclipse.xtext;

import java.util.Set;

import org.eclipse.xtext.service.AbstractServiceRegistrationFactory;

/**
 * used to register components to be used within the IDE.
 */
public class XtextUiConfig extends org.eclipse.xtext.GenXtextUiConfig {

	public Set<IServiceRegistration> registrations() {
		return super.registrations();
	}

}
