package org.eclipse.xtext;

import org.eclipse.xtext.service.ILanguageService;

public interface IGrammarAccess extends ILanguageService {

    Grammar getGrammar();

}
