package org.eclipse.xtext.parsetree.reconstr.impl;

import java.io.IOException;
import java.io.OutputStream;

import org.eclipse.xtext.parsetree.reconstr.ITokenSerializer;
import org.eclipse.xtext.parsetree.reconstr.IParseTreeConstructor.IAbstractToken;

public class DefaultTokenSerializer implements ITokenSerializer {

	public void serialize(IAbstractToken firstToken, OutputStream out) throws IOException {

	}

}
