package org.eclipse.xtext.resource;

import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.service.ILanguageService;

public interface IResourceFactory extends Resource.Factory, ILanguageService {

    /**
     * @return
     */
    String[] getModelFileExtensions();
    
}
